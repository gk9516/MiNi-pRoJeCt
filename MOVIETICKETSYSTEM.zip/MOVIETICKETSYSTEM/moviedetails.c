#include<stdio.h>
struct moviedetails{
	char name[25];
	char phone[15];
	int seat;
	int id;
};

